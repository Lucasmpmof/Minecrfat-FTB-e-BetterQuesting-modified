from __future__ import annotations

from dataclasses import dataclass, field

import networkx as nx

from core.models import QuestBook
from core.progression_graph import ProgressionGraph, compute_topological_depths


@dataclass
class ProgressionCluster:
    """
    Representa um módulo coerente de progressão de gameplay - um
    grupo de quests fortemente inter-relacionadas que, no futuro,
    poderá ser importado, analisado, adaptado e combinado pelo
    Progression Builder (V0.9+).

    Um ProgressionCluster NÃO é um capítulo, um componente conectado
    ou um mod. Ele representa coesão estrutural real dentro do grafo
    de dependências - ver ProgressionClusterDetector para o
    algoritmo de detecção.

    Os campos `detected_mods`, `compatibility_state`,
    `bridge_candidates` e `metadata` são propositalmente deixados
    vazios/None nesta milestone. Eles existem apenas para que
    milestones futuras (CompatibilityAnalyzer, ProgressionBuilder,
    BridgeAnalyzer) possam preenchê-los sem precisar alterar a forma
    do modelo.
    """

    id: str

    quest_ids: list[str] = field(default_factory=list)

    quest_count: int = 0

    chapters: list[str] = field(default_factory=list)

    # Quests sem predecessor DENTRO do cluster - onde um jogador
    # "entraria" neste módulo (podem depender de algo externo ao
    # cluster, ou serem raízes reais do questbook inteiro).
    entry_quests: list[str] = field(default_factory=list)

    # Quests sem sucessor DENTRO do cluster - onde este módulo
    # "termina" do ponto de vista interno (podem ter dependentes
    # fora do cluster, ou serem terminais reais do questbook
    # inteiro).
    exit_quests: list[str] = field(default_factory=list)

    # Subconjunto de entry_quests que também são raízes reais do
    # grafo inteiro (sem NENHUM pré-requisito, interno ou externo).
    internal_roots: list[str] = field(default_factory=list)

    # Subconjunto de exit_quests que também são terminais reais do
    # grafo inteiro (nada, interno ou externo, depende delas).
    internal_terminals: list[str] = field(default_factory=list)

    max_depth: int = 0

    average_depth: float = 0.0

    internal_dependency_count: int = 0

    external_incoming_dependencies: int = 0

    external_outgoing_dependencies: int = 0

    # ------------------------------------------------------
    # Reservado para milestones futuras. Intencionalmente vazio.
    # ------------------------------------------------------

    detected_mods: set[str] = field(default_factory=set)

    compatibility_state: str | None = None

    bridge_candidates: list = field(default_factory=list)

    metadata: dict = field(default_factory=dict)

    # ------------------------------------------------------

    def to_dict(self) -> dict:

        return {

            "id": self.id,

            "quest_ids": self.quest_ids,

            "quest_count": self.quest_count,

            "chapters": self.chapters,

            "entry_quests": self.entry_quests,

            "exit_quests": self.exit_quests,

            "internal_roots": self.internal_roots,

            "internal_terminals": self.internal_terminals,

            "max_depth": self.max_depth,

            "average_depth": self.average_depth,

            "internal_dependency_count": self.internal_dependency_count,

            "external_incoming_dependencies": self.external_incoming_dependencies,

            "external_outgoing_dependencies": self.external_outgoing_dependencies,

            "detected_mods": sorted(self.detected_mods),

            "compatibility_state": self.compatibility_state,

            "bridge_candidates": self.bridge_candidates,

            "metadata": self.metadata,

        }


class ProgressionClusterDetector:
    """
    Detecta ProgressionClusters a partir de um ProgressionGraph.

    Estratégia de clusterização
    ----------------------------
    Um cluster não é "um componente conectado" nem "um capítulo".
    Ele é um grupo de quests densamente inter-relacionadas em
    comparação com o quão esparsamente elas se conectam ao resto do
    grafo - a definição estrutural clássica de "comunidade" em
    teoria dos grafos.

    Isso é calculado via detecção de comunidades por modularidade
    (algoritmo de Louvain, `networkx.community.louvain_communities`)
    sobre a versão não-direcionada do grafo de dependências:

    - Louvain nunca funde nós que pertencem a componentes
      desconectados diferentes (não há aresta entre eles, logo a
      modularidade nunca compensaria juntá-los) - portanto, ao
      contrário de "um cluster por componente", esta abordagem NUNCA
      produz menos granularidade do que os componentes reais.
    - Mas, diferente de "um cluster por componente", Louvain também
      SUBDIVIDE um componente grande e heterogêneo (comum quando um
      questbook inteiro converge para poucos "quests-hub", como
      conquistas finais ou capítulos de acesso) em sub-módulos
      internamente coesos, que é o comportamento desejado para
      representar "módulos de progressão reutilizáveis".
    - O algoritmo é determinístico dado um `seed` fixo, e Louvain é
      quase-linear na prática (O(V log V) tipicamente), então
      escala bem para questbooks com milhares de quests.

    Quests isoladas (sem nenhuma dependência, em nenhuma direção)
    formam comunidades de tamanho 1 e são deliberadamente excluídas
    do resultado - elas não representam um "módulo de progressão"
    (mesma decisão já tomada para `ProgressionGraph.find_chains()`).

    Esta classe nunca modifica o QuestBook nem o ProgressionGraph.
    """

    def __init__(self, seed: int = 0):

        self.seed = seed

    # ------------------------------------------------------

    def detect(
        self,
        questbook: QuestBook,
        graph: ProgressionGraph | None = None,
    ) -> list[ProgressionCluster]:

        if graph is None:

            graph = ProgressionGraph.build(questbook)

        digraph = graph.graph

        if digraph.number_of_nodes() == 0:

            return []

        undirected = digraph.to_undirected()

        communities = nx.community.louvain_communities(
            undirected,
            seed=self.seed,
            weight=None,
        )

        # Ordenação determinística: maiores primeiro, desempate por
        # IDs de quest ordenados.
        sorted_communities = sorted(
            (sorted(community) for community in communities),
            key=lambda community: (-len(community), community),
        )

        clusters: list[ProgressionCluster] = []

        index = 1

        for quest_ids in sorted_communities:

            if len(quest_ids) < 2:

                # Quest isolada - não representa um módulo de
                # progressão.
                continue

            clusters.append(
                self._build_cluster(
                    cluster_id=f"cluster_{index:04d}",
                    quest_ids=quest_ids,
                    graph=graph,
                )
            )

            index += 1

        return clusters

    # ------------------------------------------------------
    # Construção de um cluster individual
    # ------------------------------------------------------

    def _build_cluster(
        self,
        cluster_id: str,
        quest_ids: list[str],
        graph: ProgressionGraph,
    ) -> ProgressionCluster:

        digraph = graph.graph

        quest_id_set = set(quest_ids)

        subgraph = digraph.subgraph(quest_ids)

        chapters = sorted(
            {
                graph.get_chapter_of(quest_id)
                for quest_id in quest_ids
                if graph.get_chapter_of(quest_id)
            }
        )

        entry_quests = sorted(
            quest_id
            for quest_id in quest_ids
            if subgraph.in_degree(quest_id) == 0
        )

        exit_quests = sorted(
            quest_id
            for quest_id in quest_ids
            if subgraph.out_degree(quest_id) == 0
        )

        internal_roots = sorted(
            quest_id
            for quest_id in entry_quests
            if digraph.in_degree(quest_id) == 0
        )

        internal_terminals = sorted(
            quest_id
            for quest_id in exit_quests
            if digraph.out_degree(quest_id) == 0
        )

        internal_dependency_count = subgraph.number_of_edges()

        external_incoming = 0

        external_outgoing = 0

        for quest_id in quest_ids:

            for parent in digraph.predecessors(quest_id):

                if parent not in quest_id_set:

                    external_incoming += 1

            for child in digraph.successors(quest_id):

                if child not in quest_id_set:

                    external_outgoing += 1

        depths = compute_topological_depths(subgraph)

        max_depth = max(depths.values()) if depths else 0

        average_depth = (
            sum(depths.values()) / len(depths)
            if depths else 0.0
        )

        return ProgressionCluster(

            id=cluster_id,

            quest_ids=quest_ids,

            quest_count=len(quest_ids),

            chapters=chapters,

            entry_quests=entry_quests,

            exit_quests=exit_quests,

            internal_roots=internal_roots,

            internal_terminals=internal_terminals,

            max_depth=max_depth,

            average_depth=average_depth,

            internal_dependency_count=internal_dependency_count,

            external_incoming_dependencies=external_incoming,

            external_outgoing_dependencies=external_outgoing,

        )